---
dg-publish: true
---

São IAs que a partir de um modelo treinado geram textos, imagens, videos ou até mesmo música.

## Exemplo de IAs Generativas:

[[TextFx]]
### Tipos de IAs Generativas:

[[(Large Language Models)]]

