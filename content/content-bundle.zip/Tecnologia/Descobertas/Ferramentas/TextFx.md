---
dg-publish: true
---

TextFX é uma ferramenta criada pelo Google em parceria e inspirada no trabalho do rapper e professor do curso de [Rap Theory & Practice](https://www.youtube.com/watch?v=zBHRsYhYb-o)do MIT Lupe Fiasco. A ferramenta consiste em uma Inteligência artifical de LLMs [[(Large Language Models)]] que utiliza-se do [PalmAPI](https://developers.googleblog.com/2023/03/announcing-palm-api-and-makersuite.html) com o objetivo de ajudar na escrita criativa, não foi pensada para substituir o compositor, poeta ou escritor, mas funcionar como coadjuvante no processo usando as LLMs para explorar a criatividade.

Você já pensou no universo de possibilidades que podem surgir de uma palavra, conceito ou frase? Em uma carreira de mais de duas décadas escrevendo como um verdadeiro _wordsmith_ pode-se imaginar que muitas técnicas são desenvolvidas, e Fiasco trás conceitos simples como em formas de explosões fonéticas para um espaço totalmente tecnológico.

>**A palavra "Expressway" do Inglês por exemplo pode ter várias conotações e significados diferentes se a dividimos ou olharmos por diferentes perspectivas**
>
> - Podemos nos referir a quantidade de silabas da palavra
> - Se analisarmos a silaba "WAY" no final de "Expressway" existem muitas ideias contidas como por exemplo pode se referir a 'weigh', 'whey', ou 'way out'
> - Pode fazer referência à filosofia chinesa de 'wu wei'
>   
>   A melhor maneira de entender o que toda essa maluquice quer dizer é olhando a referência em [Rapper x LLMs](https://youtu.be/yYp18JAvKkQ?t=136) fique mais claro o que quero dizer com tudo isso. 

A ideia central é que podemos através de uma única palavra ou frase retirar diferentes conotações que colaborem em um processo de criação, os casos de uso são infinitos desde Branding a Poesia e Filosofia.  

TextFx é um apenas o nome geral dado a um conjunto de 10 ferramentas que expandem o processo de escrita e aqui queremos falar sobre cada uma e como elas vão de fato de dar ideias:
## Simile

Crie um símile sobre uma coisa ou conceito.

Um bom simile contém uma **imagem concreta que ilustra o conceito que queremos transmitir sem ser muito óbvio.** Bons símiles são inesperados e evocativos. Abaixo estão alguns exemplos de bons similes:

| Conceito | O que ilustra isso |
|-----------|-------------------|
| uma mão amiga | Eu só venho para ajudar como o cinturão de utilidades do Batman.|
| uma garoa | A chuva era como um véu delicado, lançando uma mortalha enevoada sobre a paisagem familiar, emprestando um ar de mistério ao mundano.|

## Explode

Uma frase que soa como uma mesma é uma frase que soa como outra palavra ou frase.

Quebre uma palavra em frases de som semelhante.

| Entrada | Saída |
|-----------|-------------------|
| Comprometido | Como prometido |
| Provoque | Prove que |

## Unexpect

Para cada cena fornece-se um exemplo de como você pode incorporar detalhes adicionais para dar a essa cena uma reviravolta inesperada.

Crie uma cadeia de itens semanticamente relacionados.

| Entrada | Saída |
|-----------|-------------------|
| um bilhete de estacionamento | um bilhete de estacionamento que está escrito em sânscrito e dobrado em um cisne de origami |
| Jogar futebol | Jogar futebol com uma bola de boliche em um campo que é feito de peças de Lego |

## Chain

  

Uma cadeia de palavras é uma sequência de oito palavras onde cada palavra na sequência está semanticamente relacionada com a palavra que a precede.

Crie uma cadeia de itens semanticamente relacionados.

| Entrada | Saída |
|-----------|-------------------|
| Carta | carta, escrever, ler, livro, biblioteca, escola, refeitório, merendeira |
| Óleo | petróleo, barril, comércio, guerra, paz, tratado, sinal, caneta |
## POV

Um "hot take" é uma perspectiva que é nova e instigante. Alguns takes quentes são leves e bem-humorados, enquanto outros podem ser provocativos ou polarizadores.

Avalie um tópico através de diferentes pontos de vista.

| Entrada | Saída |
|-----------|-------------------|
| Gomas | Os ursos de goma são o lanche perfeito para pessoas que gostam de mastigar seus alimentos em submissão. Os ursos de goma são saudáveis porque são apenas frutas misturadas com um pouco de gelatina. Os ursos de goma são os M&Ms do mundo das gomas, só que eles não derretem na sua mão (ou na sua boca).|
| Celulares| Os celulares transformaram as pessoas em péssimos ouvintes. Os telefones celulares são uma ótima maneira de trapacear em testes de matemática. Os celulares revolucionaram a forma como pensamos sobre namoro e romance. Os celulares são uma tática empregada pelo governo para vigiar você. |

## Alliteration

Crie palavras específicas do tópico que começam com uma letra escolhida.

| Entrada | Geralmente relacionadas a esse tópico e começam com a(s) letra(s) | Saida |
|-----------|-----------------------------------------------------------------|-------|
| Gomas | T | tempo, melodia, tom, agudos, timbre, tablatura, tríade, tremolo, faixa, toccata, trinca |
| Cidades conhecidas | M | Madrid, Moscovo, Mumbai, Melbourne, Manila, Montreal, Munique, Milão |

## Acronym

Uma sigla é uma abreviação de várias palavras de tal forma que a própria abreviatura forma uma palavra pronunciável.

Crie um acrônimo usando as letras de uma palavra.  

| Entrada | Saída |
|---------|-------|
| amor | AMOR - Vivendo abertamente através da empatia |
| perdoar | PERDOAR - Encontrar oportunidades para liberar rancores, inspirar virtudes e empatia |

## Fuse   

Uma maneira de praticar o pensamento criativo é identificar conexões entre coisas aparentemente não relacionadas. Para cada par de coisas abaixo, fornecemos um exemplo criativo de algo que ambas as coisas têm em comum. Cada conexão é nova e inesperada, em vez de uma tecnicidade não original.

Encontre interseções entre duas coisas.

| Coisa 1 | Coisa 2 | Saída |
|---------|---------|-------|
| Avião | Grama | Tanto um avião quanto a grama desafiam a gravidade à sua maneira – um avião voando pelo ar, e a grama se erguendo contra a atração gravitacional da Terra. |
| Trabalho | Dormir | Tanto o trabalho quanto o sono podem ser associados à ideia de entrega ou libertação – o trabalho como uma forma de deixar de lado nossos desejos pessoais e servir às necessidades de uma empresa, organização ou bem maior, e o sono como uma forma de entregar o controle e a confiança nos processos naturais de nossos corpos e mentes. |
## Scene

Tanto o trabalho quanto o sono podem ser associados à ideia de entrega ou libertação – o trabalho como uma forma de deixar de lado nossos desejos pessoais e servir às necessidades de uma empresa, organização ou bem maior, e o sono como uma forma de entregar o controle e a confiança nos processos naturais de nossos corpos e mentes.

Gere detalhes sensoriais sobre uma cena.

| Entrada | Saída |
|---------|-------|
| embarcar em um avião | Um leve cheiro de fumaça de jato enquanto o avião taxia em direção à pista A voz do piloto sobre o alto-falante dizendo: "Atenção passageiros, este é seu piloto falando..." Uma criança pequena repetidamente abrindo e fechando a sombra da janela |
| minha abuela | Uma panela gigante de arroz e feijão fervendo no fogão Um pequeno rádio no balcão tocando música de seu país natal Um rosário pendurado na parede Ela falando comigo em espanhol e eu respondendo em inglês |

## Unfold

Coloque uma palavra em outras palavras ou frases.

| Entrada | Saída |
|---------|-------|
| correr | fugir, home run, correr pelo dinheiro, correr em fuga |
| luz | Sabre de luz, holofote, luz no fim do tunel, dar a luz |

-----

O uso de [[IA generativas]] gera muitos debates no cenário educacional atual, porém como podem ver existem sim maneiras de utilizar-se da inteligência artificial para uma construção em conjunto de ideias criativas, expandir horizontes, criar cenários, fundir ideias e muito mais. A ideia central de tudo isso é que você usuário esteja no controle.